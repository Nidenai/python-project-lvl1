#!/usr/bin/env python
import sys

from brain_games import cli

def main():
    if __name__ == '__main__':
        main()
print('Welcome to the Brain Games!')
cli.welcome_user()
